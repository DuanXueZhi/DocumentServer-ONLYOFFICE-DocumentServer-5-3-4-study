1) add folder chess
2) add file pluginBase.js