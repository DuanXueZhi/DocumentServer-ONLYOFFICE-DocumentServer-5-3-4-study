(function(window, undefined){

    window.Asc.plugin.init = function(text)
    {
    };

    window.Asc.plugin.button = function(id)
    {
        this.executeCommand("close", "");
    };

    window.Asc.plugin.onExternalMouseUp = function()
    {        
    };

})(window, undefined);
